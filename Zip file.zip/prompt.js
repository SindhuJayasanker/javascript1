let age = prompt("What is your age");
console.log(age);

